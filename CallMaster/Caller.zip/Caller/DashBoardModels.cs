﻿namespace CallMaster.Models
{
    public class AdminDashboardModel
    {
        public string AdminName { get; set; }
        public int TotalAgents { get; set; }
        public int TotalManagers { get; set; }
        public int TotalActiveCampaigns { get; set; }
        public int DailyCalls { get; set; }
        public float DailyIncreasedCallsPersent { get; set; }


    }

    public class AdminSharedView
    {
        public AdminDashboardModel DashboardData { get; set; }
        public IEnumerable<UserData> UsersData { get; set; } // List of users for the User Management Tab
    }

    public class AgentDashboardModel
    {
    }
    public class ManagerDashboardModel
    {
        public string ManagerName { get; set; }
        public List<AgentViewModel> ManagedAgents { get; set; }
        public List<CampaignPerformance> CampaignPerformances { get; set; } // New
        public int CurrentPage { get; set; }
        public int TotalPages { get; set; }
        public string SearchName { get; set; }
    }

    public class CampaignPerformance
    {
        public string CampaignName { get; set; }
        public int TotalCalls { get; set; }
        public int CompletedCalls { get; set; }
        public int PendingCalls { get; set; }
        public string Status { get; set; }
    }

    public class AgentViewModel
    {
        public int Id { get; set; }
        public string FullName { get; set; }
        public string Email { get; set; }
        public string Status { get; set; }
        public VoIPLoginDetails VoIPDetails { get; set; }
        public int AssignedCampaignsCount { get; set; } // New
    }


    public class UserData
    {
        public string FullName { get; set; }
        public string Role { get; set; }
        public DateTime LastLogin { get; set; }
        public string Status { get; set; } // Status as string ("Active", "Inactive", etc.)
        public string ManagerName { get; set; }
        public string Email { get; set; }
        public int Id { get; set; }


    }

}
